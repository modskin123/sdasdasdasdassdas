using LeagueSharp.Common;

using EloBuddy; 
 using LeagueSharp.Common; 
 namespace _Project_Geass.Module.Champions.Heroes.Events
{

    internal class Kalista
    {
        #region Public Constructors

        public Kalista(bool manaEnabled, Orbwalking.Orbwalker orbwalker) {}

        #endregion Public Constructors
    }

}