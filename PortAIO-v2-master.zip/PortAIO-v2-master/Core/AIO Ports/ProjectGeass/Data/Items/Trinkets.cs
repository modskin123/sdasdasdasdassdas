using EloBuddy; 
 using LeagueSharp.Common; 
 namespace _Project_Geass.Data.Items
{

    public class Trinkets
    {
        #region Public Properties

        public LeagueSharp.Common.Items.Item Orb{get;} = new LeagueSharp.Common.Items.Item(3363);

        #endregion Public Properties
    }

}