using System;
using LeagueSharp.Common;

using EloBuddy; 
 using LeagueSharp.Common; 
 namespace _Project_Geass
{

    internal class Program
    {
        #region Private Methods

        /// <summary>
        ///     Defines the entry point of the application.
        /// </summary>
        public static void Main() { OnLoad(); }

        private static void OnLoad()
        {
            // ReSharper disable once UnusedVariable
            var init=new Initializer();
        }

        #endregion Private Methods
    }

}