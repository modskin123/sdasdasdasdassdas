using System;
using LeagueSharp.Common;

using EloBuddy; 
 using LeagueSharp.Common; 
 namespace ProSeries
{
    internal class Program
    {

        public static void GameOnOnGameLoad()
        {
            ProSeries.Load();
        }
    }
}