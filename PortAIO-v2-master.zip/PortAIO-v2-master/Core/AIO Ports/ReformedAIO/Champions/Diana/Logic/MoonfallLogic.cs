using EloBuddy; 
using LeagueSharp.Common; 
namespace ReformedAIO.Champions.Diana.Logic
{
    internal class MoonfallLogic
    {
    }
}