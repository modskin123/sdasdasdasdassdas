using EloBuddy; 
using LeagueSharp.Common; 
 namespace Flowers_ADC_Series.Utility
{
    using System;
    using LeagueSharp;
    using LeagueSharp.Common;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Web.Script.Serialization;

    internal class SkinChange : Logic
    {
        static SkinChange()
        {
        }

        public static void Init()
        {
        }
    }
}
