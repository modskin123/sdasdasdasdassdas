namespace ADCCOMMON
{
    using System;
    using System.Collections.Generic;
    using EloBuddy;
    using LeagueSharp.Common;

    public static class CleaneseManager
    {
    }
}
