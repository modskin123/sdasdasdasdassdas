using System;
using LeagueSharp.Common;

using EloBuddy; 
 using LeagueSharp.Common; 
 namespace FreshBooster
{
    class Program
    {
        public static void Game_OnGameLoad()
        {
            Loader.Load();
        }
    }
}