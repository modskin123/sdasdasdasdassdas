using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LeagueSharp;
using LeagueSharp.Common;
using SharpDX;
using Color = System.Drawing.Color;

using EloBuddy; 
 using LeagueSharp.Common; 
 namespace BadaoKingdom.BadaoChampion.BadaoVeigar
{
    public static class BadaoVeigarVariables
    {
        // menu
        public static MenuItem ComboQ;
        public static MenuItem ComboWAlways;
        public static MenuItem ComboWOnCC;
        public static MenuItem ComboE;
        public static MenuItem ComboRAlways;
        public static MenuItem ComboRKillable;

        public static MenuItem ExtraEDistance; 

        public static MenuItem ClearCount;

        public static MenuItem RHp;

        public static MenuItem LaneClearQ;

        public static MenuItem JungleClearQ;
        // #
        public static Vector2 SwordPos = new Vector2();
    }
}
