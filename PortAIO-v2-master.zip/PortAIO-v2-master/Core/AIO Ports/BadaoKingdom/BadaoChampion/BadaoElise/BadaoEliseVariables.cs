using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LeagueSharp;
using LeagueSharp.Common;
using SharpDX;
using Color = System.Drawing.Color;

using EloBuddy; 
 using LeagueSharp.Common; 
 namespace BadaoKingdom.BadaoChampion.BadaoElise
{
    public static class BadaoEliseVariables
    {
        public static MenuItem ComboE;
        public static MenuItem ComboE2;
        public static MenuItem ComboR;

        public static MenuItem JungleQ;
        public static MenuItem JungleW;
        public static MenuItem JungleR;
        public static MenuItem JungleMana;

        //public static MenuItem LaneClearR;
        //public static MenuItem LaneClearMana;

    }
}
