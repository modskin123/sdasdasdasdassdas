using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LeagueSharp;
using LeagueSharp.Common;
using SharpDX;
using Color = System.Drawing.Color;

using EloBuddy; 
 using LeagueSharp.Common; 
 namespace BadaoKingdom.BadaoChampion.BadaoPoppy
{
    public static class BadaoPoppyVariables
    {
        // menu
        public static MenuItem ComboQ;
        public static MenuItem ComboW;
        public static MenuItem ComboE;
        public static MenuItem ComboRKillable;

        public static MenuItem HarassQ;

        public static MenuItem JungleQ;
        public static MenuItem JungleE;
        public static MenuItem JungleMana;

        public static MenuItem AssassinateKey;
        

        public static MenuItem AutoEInterrupt;
        public static MenuItem AutoRKS;
        public static MenuItem AutoR3Target;
        public static MenuItem AutoRInterrupt;
        //#
        public static int QCastTick;
    }
}
